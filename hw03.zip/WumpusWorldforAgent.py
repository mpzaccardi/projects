'''
Name
IDSN 599, Fall 2021
USC email
Homework 3
'''

from tkinter import *
import random
from PIL import Image, ImageTk
import time

images = []
cave = []
percepts = []

root = Tk()
root.title("Welcome to Wumpus World")
root.geometry("440x440")
root.grid()

#Player must be global so it can be moved

img = Image.open('player.png')
playerImage = ImageTk.PhotoImage(img)
img2 = Image.open('question.png')
playerImage2 = ImageTk.PhotoImage(img2)

#playerImage = PhotoImage(file="player.png")
playerLabel = Label(root, image=playerImage)

empty = Image.open('empty.png')
emptyImage = ImageTk.PhotoImage(empty)

class Room:
    def __init__(self, pit, wumpus, gold, walls):
        self.hasPit = pit
        self.hasWumpus = wumpus
        self.hasGold = gold
        self.walls = walls

    def __str__(self):
        return str(self.hasPit) + " " + str(self.hasWumpus) + " " + str(self.hasGold) + " " + str(self.walls)

class Player:
    def __init__(self):
        self.rowLocation = 0
        self.columnLocation = 0
        self.directionFacing = 'right'
        self.hasGold = False

    def __str__(self):
        return str(self.columnLocation) + ',' + str(self.rowLocation) + ',' + self.directionFacing

def makeCave():
    # Make the 10x10 cave

    pitChance = 10

    for i in range(10):
        caveRow = []
        for j in range(10):
            value = random.randrange(100)
            if value <= pitChance:
                pit = True
            else:
                pit = False

            if i == 0 and j == 0:
                # Can't have a pit at 0,0
                pit = False


            caveRow.append(Room(pit, False, False, []))

        cave.append(caveRow)

    # pick a random room for the wumpus. Remove any pit if there is one in the room
    while True:
        wumpusX = random.randrange(10)
        wumpusY = random.randrange(10)

        if wumpusX == 0 and wumpusY == 0:
            continue  # can't have the Wumpus at 0,0

        break

    # pick a random room for the gold. Remove any pit if there is one in the room. Can't be the wumpus room
    while True:
        goldX = random.randrange(10)
        goldY = random.randrange(10)

        if goldX == 0 and goldY == 0:
            continue  # can't have the gold at 0,0

        row = cave[goldX]
        if row[goldY].hasWumpus:
            #Can't have the gold where the Wumpus is
            continue

        break

    #Set the wumpus. Can't have a pit where the Wumpus is
    row = cave[wumpusX]
    row[wumpusY].hasWumpus = True
    row[wumpusY].hasPit = False

    #Set the gold. Can't have a pit where the gold is
    row = cave[goldX]
    row[goldY].hasGold = True
    row[goldY].hasPit = False

def makePercepts():
    # Create the blank percept lists for all rooms
    for i in range(10):
        perceptRow = []
        for j in range(10):
            percept = ['', '', '', '', '']
            perceptRow.append(percept)

        percepts.append(perceptRow)

    # Do the wumpus
    for i in range(10):
        caveColumn = cave[i]
        for j in range(10):
            if caveColumn[j].hasWumpus:
                rooms = [[j - 1, i], [j + 1, i], [j, i - 1], [j, i + 1]]
                for roomCoords in rooms:
                    column = roomCoords[0]
                    row = roomCoords[1]
                    if column == -1 or column == 10:
                        continue
                    if row == -1 or row == 10:
                        continue
                    tempColumn = percepts[column]
                    tempRoom = tempColumn[row]
                    tempRoom[0] = 'Stench'

    # Do the pits
    for i in range(10):
        caveRow = cave[i]
        perceptRow = percepts[i]
        for j in range(10):
            if caveRow[j].hasPit:
                rooms = [[j - 1, i], [j + 1, i], [j, i - 1], [j, i + 1]]
                for roomCoords in rooms:
                    row = roomCoords[0]
                    column = roomCoords[1]
                    if row == -1 or row == 10:
                        continue
                    if column == -1 or column == 10:
                        continue
                    tempRow = percepts[row]
                    tempRoom = tempRow[column]
                    tempRoom[1] = 'Breeze'

def getPercept(player):
    #Given the player's location, return the percept at that location
    perceptRow = percepts[player.rowLocation]
    return perceptRow[player.columnLocation]

def getRoom(player):
    caveRow = cave[player.columnLocation]
    return caveRow[player.rowLocation]

def doAction(action, player):
    #Perform the action given by the user
    direction = player.directionFacing
    row = player.columnLocation
    column = player.rowLocation
    directions = ['right','up','left','down']
    dirIndex = directions.index(direction)

    if action == "TL":
        dirIndex += 1
        if dirIndex == 4:
            dirIndex = 0

        direction = directions[dirIndex]
        player.directionFacing = direction
        return "done"
    elif action == "TR":
        dirIndex -= 1
        if dirIndex < 0:
            dirIndex = 3

        direction = directions[dirIndex]
        player.directionFacing = direction
        return "done"
    elif action == "FW":
        #Move the player forward one room if they don't hit a wall
        if dirIndex == 0:
            moveDirection = [1,0]
        elif dirIndex == 1:
            moveDirection = [0,-1]
        elif dirIndex == 2:
            moveDirection = [-1,0]
        else:
            moveDirection = [0,1]

        row += moveDirection[0]
        column += moveDirection[1]

        if row < 0 or row > 9:
            #player tried to move into wall
            print("You bumped into a wall. You didn't move")
            return 'bump'
        if column < 0 or column > 9:
            #player tried to move into wall
            print("You bumped into a wall. You didn't move")
            return 'bump'

        #This is a valid move. Remove the player image from this location. Put an empty image here
        oldRow = row - moveDirection[0]
        oldColumn = column - moveDirection[1]
        l = images[oldRow]
        l[oldColumn].config(image=emptyImage)

        #Move is correct. Check for a pit or an alive wumpus
        player.rowLocation = column
        player.columnLocation = row

        caveRow = cave[row]
        room = caveRow[column]

        if room.hasWumpus:
            #player is dead
            print("You were horribly eaten by the Wumpus")
            return 'dead'
        elif room.hasPit:
            #player is dead
            print("You fell into a pit and died a nasty death")
            return "dead"
        elif room.hasGold:
            print("You have found the gold")
            percept = getPercept(player)
            percept[2] = "Glitter"
            l = images[row]
            l[column].config(image=playerImage)
            return "gold"
        else:
            #Update player image location
            l = images[row]
            l[column].config(image=playerImage)

    elif action == "GR":
        room = getRoom(player)

        if room.hasGold:
            #correct Grab action
            print("You have the gold")
            player.hasGold = True
            percept = getPercept(player)
            percept[2] = ""
            room.hasGold = False
            return "gold"
        else:
            print("You are not in the room with the gold")
            return "no gold"
    elif action == "CL":
        if row == 0 and column == 0:
            #correct Climb action. Game is over
            print("You have successfully exited the cave!")
            if player.hasGold:
                print("You exited the cave with the gold. Congratulations!")
            else:
                print("You exited the cave without the gold. Shame on you!")
            return "over"
        else:
            print("You are not in the correct room")
            return "not over"

    return 'alive'

def main():
    player = Player()

    # modify the window
    makeCave()
    makePercepts()

    # Create the empty seeming cave
    for i in range(10):
        imagerow = []
        for j in range(10):
            emptyLabel = Label(root, image=emptyImage)
            imagerow.append(emptyLabel)
            emptyLabel.grid(row=j, column=i, rowspan=1, columnspan=1)

        images.append(imagerow)

#Remove all this code except for the Player when ready
    # Add the Player to the cave
    l = images[0]
    l[0].config(image=playerImage)

    while True:
        root.update()  # This is necessary so you see the graphics updated

        # This is where your code goes
        percept = getPercept(player)  # Gives you the percept for the room you are in
        print(percept)

        # This is where you have your code to decide what action to take given the current percept
        action = chooseAction(percept, player)

        # With a selected action, have it executed
        returnValue = doAction(action, player)
        if returnValue == "dead" or returnValue == "over":
            exit(0)

'''
This is where your code is going to go. Define all your data structures and the chooseAction method below here.
Do not change any code that has been provided to you without asking permission first.

Define your data structures above the chooseAction function
'''

goHomeList = []
distanceScore = []
forwardBaseReturn = []
retreatList = []
actionList = []
visitedRooms = []
adjacentRooms = []
clearanceLevel = 1
forwardBaseReturnState = False
hasGold = False
retreat = False
# move to the first room that sensor something - run back
moveForward = True
# move back to the 0,0 coordinate to climb out
goHome = False

Rooms = {}
for x in range(0, 10):
    for y in range(0, 10):
        room = "[" + str(x) + "," + " " + str(y) + "]"
        Rooms[room] = 0



def chooseAction(percept, player):
    time.sleep(.1)  # Pauses the program for 5 seconds so your agent doesn't run too fast
    # write global so that pyCharm can identify the global outside of def chooseAction
    global distanceScore
    global forwardBaseReturnState
    global forwardBaseReturn
    global goHomeList
    global clearanceLevel
    global hasGold
    global moveForward
    global goHome
    global retreatList
    global retreat
    global actionList
    global adjacentRooms
    global visitedRooms
    global Rooms

    #set current room to safe
    Rooms[str(player.rowLocation), str(player.columnLocation)] = 0

    print(clearanceLevel)


    #identify adjacent rooms
    adjacentRooms = [[player.rowLocation, player.columnLocation - 1], [player.rowLocation, player.columnLocation + 1], [player.rowLocation - 1, player.columnLocation], [player.rowLocation + 1, player.columnLocation]]

    #check if this is furthest agent has gotten
    if len(actionList) != 0 and forwardBaseReturnState == False:
        forwardBaseReturn += actionList[-2:-1]
    if len(distanceScore) != 0:
        if (player.rowLocation + player.columnLocation) > distanceScore[-1]:
            forwardBaseReturn = []

    #if space after FOB is also unsafe, move forward again
    if forwardBaseReturnState == True and len(forwardBaseReturn) == 0:
        if 'Stench' in percept or 'Breeze' in percept:
            return 'FW'
        else:
            moveForward = True
            forwardBaseReturnState = False

    #check if counter works
    for room in adjacentRooms:
        if room not in visitedRooms and -1 < room[0] < 10 and -1 < room[1] < 10:
            stringRoom = str(room)

    #increase danger level of surrounding spaces if percept detected
    if ('Stench' in percept or 'Breeze' in percept) and [player.rowLocation, player.columnLocation] not in visitedRooms:
        for room in adjacentRooms:
            if room not in visitedRooms and -1 < room[0] < 10 and -1 < room[1] < 10:
                stringRoom = str(room)
                Rooms[stringRoom] += 1

    #record if room is visited
    if [player.rowLocation, player.columnLocation] not in visitedRooms:
        distanceScore.append(player.rowLocation + player.columnLocation)
        distanceScore.sort()
        print("distance scores", distanceScore)
        visitedRooms.append([player.rowLocation, player.columnLocation])

    print("base return list", forwardBaseReturn)

    #determine next possible moves
    nextMove = []

    for room in adjacentRooms:
        if clearanceLevel == 1:
            if room not in visitedRooms and -1 < room[0] < 10 and -1 < room[1] < 10:
                nextMove.append(room)
        elif room not in visitedRooms and -1 < room[0] < 10 and -1 < room[1] < 10 and Rooms[str(room)] <= clearanceLevel:
            nextMove.append(room)


    if moveForward:
        print('moving')
        #grab and return with gold
        if 'Glitter' in percept:
            print("the gold!")
            # room not safe
            goHomeList += actionList
            goHomeList.append('TR')
            goHomeList.append('TR')
            moveForward = False
            retreat = False
            hasGold = True
            goHome = True
            forwardBaseReturnState = False
            action = 'GR'
        #if no safe next moves, go home
        elif len(nextMove) == 0:
            print("run!")
            # room not safe
            goHomeList += actionList
            goHomeList.append('TR')
            moveForward = False
            retreat = False
            goHome = True
            action = 'TL'
        #increase clearance if returned all the way home without further options to explore
        elif ('Stench' in percept or 'Breeze' in percept) and clearanceLevel == 1:
            if len(actionList) == 0:
                clearanceLevel += 1
                return
            retreatList.append('FW')
            retreatList.append('TL')
            moveForward = False
            retreat = True
            action = 'TL'
        else:
            if ('Stench' in percept or 'Breeze' in percept) and clearanceLevel != 1:
                clearanceLevel -= 1
            # determining next move
            if (nextMove[0][0] - player.rowLocation) == 1 and (nextMove[0][1] - player.columnLocation) == 0:
                if player.directionFacing == 'down':
                    action = 'FW'
                    actionList.append(action)
                    return action
                action = 'TR'
                actionList.append(action)
                return action
            elif (nextMove[0][0] - player.rowLocation) == -1 and (nextMove[0][1] - player.columnLocation) == 0:
                if player.directionFacing == 'up':
                    action = 'FW'
                    actionList.append(action)
                    return action
                action = 'TR'
                actionList.append(action)
                return action
            elif (nextMove[0][0] - player.rowLocation) == 0 and (nextMove[0][1] - player.columnLocation) == 1:
                if player.directionFacing == 'right':
                    action = 'FW'
                    actionList.append(action)
                    return action
                action = 'TR'
                actionList.append(action)
                return action
            elif (nextMove[0][0] - player.rowLocation) == 0 and (nextMove[0][1] - player.columnLocation) == -1:
                if player.directionFacing == 'left':
                    action = 'FW'
                    actionList.append(action)
                    return action
                action = 'TR'
                actionList.append(action)
                return action
            # room is safe
            action = 'FW'


        print("moving")
        actionList.append(action)
        return action

    #retreat from unsafe spot
    elif retreat:
    

        "retreating"
        if len(retreatList) == 0:
            moveForward = True
            retreat = False
            action = 'TL'
            actionList.append(action)
            return action
        action = retreatList.pop()
        actionList.append(action)
        return action


    elif goHome:
        print("going home")
        #continue exploring if new rooms located while going home
        if 'Stench' not in percept and 'Breeze' not in percept and len(nextMove) != 0 and hasGold == False:
            moveForward = True
            retreat = False
            goHome = False
            goHomeList = []
            return
        # pop the entire list to get a zero
        if len(goHomeList) == 0 and hasGold == False:
            forwardBaseReturnState = True
            goHome = False
            moveForward = False
            visitedRooms = []
            forwardBaseReturn.append('FW')
            forwardBaseReturn.append('TL')
            actionList.append('FW')
            actionList.append('TL')
            actionList.append('TL')
            return 'TR'
        if (len(goHomeList) == 0 or (player.rowLocation == 0 and player.columnLocation == 0)) and hasGold == True:
            # in room 0,0
            return 'CL'
        action = goHomeList.pop()
        # we need this if a turn action can be in our list
        # for testing the moveForward and climb out we # the following lines
        if action == 'TL':
            action = 'TR'
        elif action == 'TR':
            action = 'TL'
        actionList.append(action)
        return action

    elif forwardBaseReturnState:
        if len(forwardBaseReturn) == 0:
            clearanceLevel = 1
            actionList.append('FW')
            return 'FW'
        if 'Glitter' in percept:
            print("the gold!")
            # room not safe
            goHomeList += actionList
            goHomeList.append('TR')
            goHomeList.append('TR')
            moveForward = False
            retreat = False
            hasGold = True
            goHome = True
            forwardBaseReturnState = False
            action = 'GR'
        action = forwardBaseReturn.pop()
        if action == 'TL':
            action = 'TR'
        elif action == 'TR':
            action = 'TL'
        actionList.append(action)
        print("returning to FOB")
        actionList.append(action)
        return action



main()
